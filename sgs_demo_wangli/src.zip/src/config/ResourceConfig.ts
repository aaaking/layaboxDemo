/*
* name;
*/
class ResourceConfig {
    constructor() {

    }

    public static login: string = "res/atlas/login.atlas";
    public static comp: string = "res/atlas/comp.atlas";
    public static cards: string = "res/atlas/cards.atlas";
    public static cardsname: string = "res/atlas/cardsname.atlas";
    public static menu: string = "res/atlas/menu.atlas";
    public static showcards: string = "res/atlas/showcards.atlas";

}