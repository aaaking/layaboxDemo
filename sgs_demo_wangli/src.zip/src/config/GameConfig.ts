/*
* name;
*/
class GameConfig{
    constructor(){

    }

    private static cfgHero:any;

    public static getCfg():void{
        GameConfig.cfgHero= Laya.loader.getRes("config/hero.json");
    }

    public static getCfgHeroById(id:number):any{
        for(var item in GameConfig.cfgHero){
            if (GameConfig.cfgHero[item].id==id)
                return GameConfig.cfgHero[item];
        }
    }
    // public static RPC_ADDRESS = "0x10339a4314ad986c995aa7e8d76b04f796945a7e"
     
    // public static RPC_URL = "http://10.225.21.5:8118"
    
    // public static BASE_COIN = "0x8321042a47ec4aa8330bf63d074e79d0e30642c7"
    
    // public static BASE_PASS = "00"
    public static RPC_ADDRESS = "0x9b5c79bc695a4e825a07761f82955d171bc1bace"
    public static RPC_URL = "http://127.0.0.1:8545"
    public static BASE_COIN = "0x6fcc37884ff905bdfec44e26d01910b3191914fa"
    public static BASE_PASS = ""

}